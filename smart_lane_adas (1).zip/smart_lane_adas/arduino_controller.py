"""USB-serial link to the Arduino. Sends one character per warning state.

S = safe | L = left drift | R = right drift | V = vehicle too close | C = critical (lane + vehicle)
"""
import time
import serial
import serial.tools.list_ports


class ArduinoController:
    def __init__(self, port=None, baud=9600, enabled=True):
        self.ser = None
        self.last_state = None
        self.last_sent = 0
        if not enabled:
            print("[Arduino] disabled (simulation mode)")
            return
        port = port or self._find_port()
        if not port:
            print("[Arduino] no board found -> simulation mode")
            return
        try:
            self.ser = serial.Serial(port, baud, timeout=0.1)
            time.sleep(2.0)   # Arduino resets when the port opens
            print(f"[Arduino] connected on {port}")
        except serial.SerialException as e:
            print(f"[Arduino] cannot open {port}: {e} -> simulation mode")

    @staticmethod
    def _find_port():
        for p in serial.tools.list_ports.comports():
            d = (p.description or "").lower() + (p.manufacturer or "").lower()
            if any(k in d for k in ("arduino", "ch340", "usb serial", "wch", "ftdi", "cp210")):
                return p.device
        return None

    def send(self, state):
        # send on change, and repeat every 0.5 s as a heartbeat (Arduino fails safe on timeout)
        now = time.time()
        if state != self.last_state or now - self.last_sent > 0.5:
            if self.ser:
                try:
                    self.ser.write(state.encode())
                except serial.SerialException:
                    self.ser = None
                    print("[Arduino] connection lost")
            self.last_state, self.last_sent = state, now

    def close(self):
        if self.ser:
            self.send("S")
            self.ser.close()
