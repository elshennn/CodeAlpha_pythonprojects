"""On-screen simulation of the Arduino LEDs + buzzer (mirrors driver_assist.ino timing)."""
import time
import cv2


class VirtualPanel:
    def __init__(self, sound=True):
        self.sound = sound
        self._last_beep = False
        try:
            import winsound
            self._winsound = winsound
        except ImportError:
            self._winsound = None

    def outputs(self, state, t=None):
        """Return (green, left, right, red, buzzer) booleans, same logic as the Arduino sketch."""
        ms = int((t if t is not None else time.time()) * 1000)
        if state == "S":
            return True, False, False, False, False
        if state in ("L", "R"):
            blink, beep = (ms // 250) % 2 == 1, (ms % 1000) < 120
            return False, blink and state == "L", blink and state == "R", False, beep
        if state == "V":
            b = (ms // 150) % 2 == 1
            return False, False, False, b, b
        b = (ms // 80) % 2 == 1          # 'C' critical
        return False, b, b, True, b

    def draw(self, frame, state):
        g, l, r, red, bz = self.outputs(state)
        h, w = frame.shape[:2]
        x0, y0 = w - 330, h - 80
        cv2.rectangle(frame, (x0 - 10, y0 - 10), (w - 10, h - 10), (30, 30, 30), -1)
        items = [("L", l, (0, 215, 255)), ("OK", g, (0, 255, 0)),
                 ("R", r, (0, 215, 255)), ("STOP", red, (0, 0, 255))]
        for i, (name, on, col) in enumerate(items):
            cx = x0 + 30 + i * 62
            cv2.circle(frame, (cx, y0 + 25), 18, col if on else (70, 70, 70), -1)
            cv2.circle(frame, (cx, y0 + 25), 18, (200, 200, 200), 1)
            cv2.putText(frame, name, (cx - 18, y0 + 62), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (220, 220, 220), 1)
        cv2.putText(frame, "BUZZER", (x0 + 258, y0 + 62), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (220, 220, 220), 1)
        cv2.putText(frame, ")))" if bz else "", (x0 + 262, y0 + 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 200, 255), 2)
        if self.sound and bz and not self._last_beep and self._winsound:
            self._winsound.Beep(2000, 60)      # Windows only; other OS: visual only
        self._last_beep = bz
        return frame
