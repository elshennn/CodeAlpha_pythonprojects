"""Smart Lane Detection & Driver Assistance System - main application.

Examples:
  python main.py --source 0                      # webcam + Arduino auto-detect
  python main.py --source road.mp4 --port COM3   # video file
  python main.py --source road.mp4 --no-arduino  # no hardware
"""
import argparse
import time
import cv2

from lane_detector import LaneDetector
from vehicle_detector import VehicleDetector
from arduino_controller import ArduinoController
from virtual_panel import VirtualPanel

STATE_TEXT = {"S": "SAFE", "L": "LANE DEPARTURE LEFT", "R": "LANE DEPARTURE RIGHT",
              "V": "VEHICLE TOO CLOSE", "C": "CRITICAL!"}
STATE_COLOR = {"S": (0, 200, 0), "L": (0, 165, 255), "R": (0, 165, 255),
               "V": (0, 0, 255), "C": (0, 0, 255)}


def decide(lane_warn, vehicle_near):
    if lane_warn and vehicle_near:
        return "C"
    if vehicle_near:
        return "V"
    return lane_warn or "S"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", default="0", help="camera index or video path")
    ap.add_argument("--port", default=None, help="serial port, e.g. COM3 or /dev/ttyUSB0")
    ap.add_argument("--no-arduino", action="store_true")
    ap.add_argument("--model", default="yolov8n.pt")
    ap.add_argument("--width", type=int, default=960)
    ap.add_argument("--yolo-every", type=int, default=2, help="run YOLO every N frames")
    ap.add_argument("--depart", type=float, default=0.25, help="lane departure threshold")
    ap.add_argument("--near", type=float, default=0.72, help="vehicle 'near' threshold (0-1)")
    ap.add_argument("--headless", action="store_true", help="no window (testing)")
    ap.add_argument("--max-frames", type=int, default=0)
    ap.add_argument("--save", default=None, help="save output video path")
    args = ap.parse_args()

    src = int(args.source) if args.source.isdigit() else args.source
    cap = cv2.VideoCapture(src)
    if not cap.isOpened():
        raise SystemExit(f"Cannot open source: {args.source}")

    lane = LaneDetector(depart_thresh=args.depart)
    veh = VehicleDetector(model=args.model, near_ratio=args.near)
    arduino = ArduinoController(port=args.port, enabled=not args.no_arduino)
    panel = VirtualPanel() if arduino.ser is None else None   # simulate hardware when no board

    writer, frame_i, dets, vehicle_near = None, 0, [], False
    candidate, stable_count, state = "S", 0, "S"
    t_prev = time.time()

    while True:
        ok, frame = cap.read()
        if not ok:
            if isinstance(src, str):                 # loop video files
                cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                continue
            break
        h0, w0 = frame.shape[:2]
        frame = cv2.resize(frame, (args.width, int(h0 * args.width / w0)))

        info = lane.process(frame)
        if frame_i % args.yolo_every == 0:
            dets = veh.detect(frame)
        vehicle_near = veh.check_ahead(dets, lane, frame.shape)

        # debounce: new state must hold for 3 consecutive frames
        new = decide(info["warning"], vehicle_near)
        if new == candidate:
            stable_count += 1
        else:
            candidate, stable_count = new, 1
        if stable_count >= 3:
            state = candidate
        arduino.send(state)

        out = lane.draw(frame, info)
        out = veh.draw(out, dets)
        fps = 1 / max(time.time() - t_prev, 1e-6)
        t_prev = time.time()
        cv2.rectangle(out, (0, 0), (out.shape[1], 70), (30, 30, 30), -1)
        cv2.putText(out, STATE_TEXT[state], (15, 32), cv2.FONT_HERSHEY_SIMPLEX, 0.9, STATE_COLOR[state], 3)
        lane_txt = f'offset {info["offset"]:+.2f}' if info["lane_found"] else "lane: searching..."
        cv2.putText(out, f"{lane_txt} | vehicles {len(dets)} | FPS {fps:.0f}", (15, 58),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1)

        if panel:
            panel.draw(out, state)
        if args.save:
            if writer is None:
                writer = cv2.VideoWriter(args.save, cv2.VideoWriter_fourcc(*"mp4v"), 25,
                                         (out.shape[1], out.shape[0]))
            writer.write(out)
        if not args.headless:
            cv2.imshow("Smart Lane ADAS  (q = quit)", out)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break
        if args.max_frames and frame_i >= args.max_frames:
            break
        frame_i += 1

    arduino.close()
    cap.release()
    if writer:
        writer.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
