"""Lane detection: Canny + ROI + Hough Transform + polynomial (curve) fitting."""
from collections import deque
import cv2
import numpy as np


class LaneDetector:
    def __init__(self, smooth=8, roi_top=0.60, curve_degree=2, depart_thresh=0.25):
        self.roi_top = roi_top              # top edge of ROI (fraction of frame height)
        self.curve_degree = curve_degree    # 1 = straight lines, 2 = curved lanes
        self.depart_thresh = depart_thresh  # offset / lane_width that triggers a warning
        self.left_hist = deque(maxlen=smooth)
        self.right_hist = deque(maxlen=smooth)
        self.left_fit = None
        self.right_fit = None

    # ---------- preprocessing ----------
    def roi_polygon(self, w, h):
        t = int(self.roi_top * h)
        return np.array([[(int(0.03 * w), h), (int(0.42 * w), t),
                          (int(0.58 * w), t), (int(0.97 * w), h)]], np.int32)

    def _edges(self, frame):
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.createCLAHE(2.0, (8, 8)).apply(gray)       # helps in shadows
        blur = cv2.GaussianBlur(gray, (5, 5), 0)
        edges = cv2.Canny(blur, 50, 150)
        mask = np.zeros_like(edges)
        cv2.fillPoly(mask, self.roi_polygon(frame.shape[1], frame.shape[0]), 255)
        return cv2.bitwise_and(edges, mask)

    # ---------- fitting ----------
    def _fit(self, pts):
        """Fit x = f(y). Returns coeffs padded to length 3 [a, b, c] or None."""
        if len(pts) < 4:
            return None
        pts = np.array(pts, dtype=np.float64)
        ys, xs = pts[:, 1], pts[:, 0]
        if np.ptp(ys) < 20:
            return None
        deg = self.curve_degree if (self.curve_degree == 2 and len(pts) >= 8) else 1
        c = np.polyfit(ys, xs, deg)
        return np.concatenate([np.zeros(3 - len(c)), c])

    @staticmethod
    def _avg(hist, new):
        if new is not None:
            hist.append(new)
        return np.mean(hist, axis=0) if hist else None

    # ---------- main ----------
    def process(self, frame):
        h, w = frame.shape[:2]
        edges = self._edges(frame)
        lines = cv2.HoughLinesP(edges, 1, np.pi / 180, threshold=30,
                                minLineLength=30, maxLineGap=80)
        left_pts, right_pts = [], []
        if lines is not None:
            for x1, y1, x2, y2 in lines[:, 0]:
                if x1 == x2:
                    continue
                slope = (y2 - y1) / (x2 - x1)
                if abs(slope) < 0.4:        # ignore near-horizontal lines
                    continue
                if slope < 0 and x1 < w * 0.55 and x2 < w * 0.55:
                    left_pts += [(x1, y1), (x2, y2)]
                elif slope > 0 and x1 > w * 0.45 and x2 > w * 0.45:
                    right_pts += [(x1, y1), (x2, y2)]

        self.left_fit = self._avg(self.left_hist, self._fit(left_pts))
        self.right_fit = self._avg(self.right_hist, self._fit(right_pts))

        info = {"lane_found": False, "offset": 0.0, "warning": None}
        if self.left_fit is not None and self.right_fit is not None:
            xl = np.polyval(self.left_fit, h)
            xr = np.polyval(self.right_fit, h)
            width = xr - xl
            if 0.2 * w < width < 1.2 * w:
                info["lane_found"] = True
                center = (xl + xr) / 2.0
                # + => vehicle is right of lane centre, - => left
                info["offset"] = (w / 2.0 - center) / width
                if info["offset"] > self.depart_thresh:
                    info["warning"] = "R"
                elif info["offset"] < -self.depart_thresh:
                    info["warning"] = "L"
        return info

    def lane_x_at(self, y):
        """Left/right lane x at image row y (None if unavailable)."""
        if self.left_fit is None or self.right_fit is None:
            return None
        return float(np.polyval(self.left_fit, y)), float(np.polyval(self.right_fit, y))

    def draw(self, frame, info):
        h, w = frame.shape[:2]
        out = frame.copy()
        cv2.polylines(out, self.roi_polygon(w, h), True, (255, 120, 0), 1)
        if self.left_fit is None or self.right_fit is None:
            return out
        ys = np.linspace(int(self.roi_top * h), h - 1, 40)
        lx = np.polyval(self.left_fit, ys)
        rx = np.polyval(self.right_fit, ys)
        left = np.array([lx, ys]).T.astype(np.int32)
        right = np.array([rx, ys]).T.astype(np.int32)
        color = (0, 255, 0) if info["warning"] is None else (0, 165, 255)
        overlay = out.copy()
        cv2.fillPoly(overlay, [np.vstack([left, right[::-1]])], color)
        out = cv2.addWeighted(overlay, 0.3, out, 0.7, 0)
        cv2.polylines(out, [left], False, (0, 0, 255), 4)
        cv2.polylines(out, [right], False, (255, 0, 0), 4)
        return out
