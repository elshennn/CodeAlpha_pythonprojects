# Smart Lane Detection & Driver Assistance System (OpenCV + YOLO + Arduino)

## 1. How it works
Camera/video -> Canny + ROI + Hough + polynomial fit (lanes) -> YOLOv8 (cars, buses, trucks, motorcycles)
-> warning logic -> one character over USB serial -> Arduino drives LEDs + buzzer.

| Char | Meaning | Green | Yellow L | Yellow R | Red | Buzzer |
|------|---------|-------|----------|----------|-----|--------|
| S | Safe | ON | - | - | - | - |
| L | Drifting left | - | blink | - | - | short beep /1s |
| R | Drifting right | - | - | blink | - | short beep /1s |
| V | Vehicle too close in your lane | - | - | - | blink | fast beeps |
| C | Lane drift + vehicle close | - | fast | fast | ON | rapid beeps |
| (link lost >2 s) | Fail-safe | - | slow blink | slow blink | - | - |

## 2. Hardware list
| Qty | Part | Note |
|-----|------|------|
| 1 | Arduino Uno / Nano (or clone) | USB cable to PC |
| 1 | Green LED, 1 Red LED, 2 Yellow LEDs | 5 mm |
| 4 | 220 ohm resistor | one per LED (330 ohm also fine) |
| 1 | **Active** buzzer 5 V | has a built-in oscillator (if 2 pins: + is longer) |
| 1 | Breadboard + jumper wires | |
| 1 | USB webcam (or laptop camera / dashcam video file) | |
| opt | 1 k ohm resistor + NPN transistor (BC547/2N2222) | only for a louder / high-current buzzer |
| opt | 12 V -> 5 V converter, Arduino enclosure | for in-car demo |

## 3. Wiring
| Arduino pin | Goes to |
|-------------|---------|
| D8  | 220 ohm -> Green LED anode (+) |
| D9  | 220 ohm -> Yellow LED (LEFT) anode |
| D10 | 220 ohm -> Yellow LED (RIGHT) anode |
| D11 | 220 ohm -> Red LED anode |
| D12 | Buzzer + (positive) |
| GND | All LED cathodes (short leg) + Buzzer - (via breadboard GND rail) |

```
 D8  --[220]--|>|-- GND   (green)
 D9  --[220]--|>|-- GND   (yellow left)
 D10 --[220]--|>|-- GND   (yellow right)
 D11 --[220]--|>|-- GND   (red)
 D12 -----(+) BUZZER (-)-- GND
```
Layout tip: place yellow-left, green, red, yellow-right in a row so the lights match the direction of drift.
Power: the Arduino is powered from the PC through the same USB cable that carries the serial data.

## 4. Software setup
1. Install Python 3.9-3.12 and VS Code (+ Python extension).
2. Open the project folder in VS Code, then in the terminal:
   ```
   python -m venv venv
   venv\Scripts\activate          (Windows)   |   source venv/bin/activate  (Linux/Mac)
   pip install -r requirements.txt
   ```
3. Install Arduino IDE, open `arduino/driver_assist/driver_assist.ino`, pick your board + port, Upload.
   **Close the Arduino Serial Monitor afterwards** (it would block the port).
4. Run:
   ```
   python main.py --source 0                       # webcam, auto-detect Arduino
   python main.py --source road.mp4 --port COM3    # video + chosen port
   python main.py --source road.mp4 --no-arduino   # software only
   ```
   Press `q` to quit. The YOLO weights (`yolov8n.pt`) download automatically on the first run.

## 4b. No hardware yet?
Run `python main.py --source road.mp4 --no-arduino`. A virtual panel (LEDs + buzzer) is drawn bottom-right of the window and behaves exactly like the Arduino (beeps on Windows).

## 5. Testing hardware without the camera
Open Arduino Serial Monitor (9600 baud) and type S, L, R, V, C one by one (set "No line ending").
The self-test at power-up flashes every LED and beeps once.

## 6. Calibration (important for good results)
- ROI shape: edit `roi_polygon()` in `lane_detector.py` and `--width`; the blue outline on screen shows it.
  Make sure it covers your lane but not the car bonnet/hood.
- `--depart 0.25`: lower = more sensitive lane warning.
- `--near 0.72`: a vehicle in your lane whose box bottom passes 72 % of frame height = "too close". Adjust per camera mount.
- `--yolo-every 3` for more FPS on slow laptops. Use `--model yolov8s.pt` for better accuracy.
- Mount the camera centred on the car/test rig, looking straight ahead.

## 7. Troubleshooting
| Problem | Fix |
|---------|-----|
| "no board found" | Install CH340/CP210x driver for clones; pass `--port COM5` |
| Port busy / access denied | Close Serial Monitor / Arduino IDE serial window |
| Lanes jitter or vanish | Better lighting, tune ROI, raise `smooth` in LaneDetector |
| Low FPS | `--width 640`, `--yolo-every 3`, use GPU build of PyTorch |
| Buzzer silent | You may have a passive buzzer; swap for active, or use `tone()` |
| LED never lights | Check polarity (long leg to resistor/pin) |

## 8. Future work
Ultrasonic distance sensor for real distance, MPU6050/GPS speed input, traffic-sign recognition,
Lane-change signalling, deep-learning lane model (e.g. UFLD), Raspberry Pi/Jetson deployment.
