"""Vehicle detection with a pretrained YOLO model (COCO classes)."""
from ultralytics import YOLO

# COCO ids: 2 car, 3 motorcycle, 5 bus, 7 truck
VEHICLE_CLASSES = {2: "car", 3: "motorcycle", 5: "bus", 7: "truck"}


class VehicleDetector:
    def __init__(self, model="yolov8n.pt", conf=0.40, imgsz=640, near_ratio=0.72):
        self.model = YOLO(model)    # auto-downloads on first run
        self.conf = conf
        self.imgsz = imgsz
        self.near_ratio = near_ratio  # box bottom below this fraction of frame height = "too close"

    def detect(self, frame):
        res = self.model.predict(frame, conf=self.conf, imgsz=self.imgsz,
                                 classes=list(VEHICLE_CLASSES), verbose=False)[0]
        dets = []
        for b in res.boxes:
            x1, y1, x2, y2 = map(int, b.xyxy[0].tolist())
            dets.append({"box": (x1, y1, x2, y2),
                         "label": VEHICLE_CLASSES[int(b.cls[0])],
                         "conf": float(b.conf[0])})
        return dets

    def check_ahead(self, dets, lane_detector, frame_shape):
        """Mark each detection in_lane / near. Returns True if a vehicle in our lane is near."""
        h, w = frame_shape[:2]
        danger = False
        for d in dets:
            x1, y1, x2, y2 = d["box"]
            cx = (x1 + x2) / 2
            lanes = lane_detector.lane_x_at(y2)
            if lanes:
                in_lane = lanes[0] < cx < lanes[1]
            else:                                   # fallback: central corridor
                in_lane = 0.35 * w < cx < 0.65 * w
            d["in_lane"] = in_lane
            d["near"] = in_lane and (y2 / h) > self.near_ratio
            danger = danger or d["near"]
        return danger

    @staticmethod
    def draw(frame, dets):
        import cv2
        for d in dets:
            x1, y1, x2, y2 = d["box"]
            color = (0, 0, 255) if d.get("near") else (0, 255, 255) if d.get("in_lane") else (200, 200, 200)
            cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
            cv2.putText(frame, f'{d["label"]} {d["conf"]:.2f}', (x1, max(15, y1 - 6)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
        return frame
