/*
  Smart Lane Detection & Driver Assistance - Arduino side
  Receives one char over USB serial (9600 baud):
    S safe | L left drift | R right drift | V vehicle too close | C critical
  Fail-safe: if no data for 2 s, yellow LEDs blink slowly (link lost).
*/
const uint8_t PIN_GREEN  = 8;
const uint8_t PIN_LEFT   = 9;    // yellow, left drift
const uint8_t PIN_RIGHT  = 10;   // yellow, right drift
const uint8_t PIN_RED    = 11;   // vehicle warning
const uint8_t PIN_BUZZER = 12;   // ACTIVE buzzer
const unsigned long LINK_TIMEOUT = 2000;

char state = 'S';
unsigned long lastRx = 0;

void setOutputs(bool g, bool l, bool r, bool red, bool bz) {
  digitalWrite(PIN_GREEN, g);
  digitalWrite(PIN_LEFT, l);
  digitalWrite(PIN_RIGHT, r);
  digitalWrite(PIN_RED, red);
  digitalWrite(PIN_BUZZER, bz);
}

void selfTest() {
  const uint8_t pins[] = {PIN_GREEN, PIN_LEFT, PIN_RIGHT, PIN_RED};
  for (uint8_t i = 0; i < 4; i++) {
    digitalWrite(pins[i], HIGH);
    delay(150);
    digitalWrite(pins[i], LOW);
  }
  digitalWrite(PIN_BUZZER, HIGH); delay(100); digitalWrite(PIN_BUZZER, LOW);
}

void setup() {
  const uint8_t outs[] = {PIN_GREEN, PIN_LEFT, PIN_RIGHT, PIN_RED, PIN_BUZZER};
  for (uint8_t i = 0; i < 5; i++) pinMode(outs[i], OUTPUT);
  Serial.begin(9600);
  selfTest();
  lastRx = millis();
}

void loop() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == 'S' || c == 'L' || c == 'R' || c == 'V' || c == 'C') {
      state = c;
      lastRx = millis();
    }
  }

  unsigned long t = millis();

  if (t - lastRx > LINK_TIMEOUT) {                  // link lost
    bool b = (t / 700) % 2;
    setOutputs(false, b, b, false, false);
    return;
  }

  switch (state) {
    case 'S':                                       // all good
      setOutputs(true, false, false, false, false);
      break;
    case 'L': {                                     // left drift: blink left LED + short beep
      bool blink = (t / 250) % 2;
      bool beep  = (t % 1000) < 120;
      setOutputs(false, blink, false, false, beep);
      break;
    }
    case 'R': {                                     // right drift
      bool blink = (t / 250) % 2;
      bool beep  = (t % 1000) < 120;
      setOutputs(false, false, blink, false, beep);
      break;
    }
    case 'V': {                                     // vehicle too close
      bool blink = (t / 150) % 2;
      setOutputs(false, false, false, blink, blink);
      break;
    }
    case 'C': {                                     // critical: everything fast
      bool blink = (t / 80) % 2;
      setOutputs(false, blink, blink, true, blink);
      break;
    }
  }
}
